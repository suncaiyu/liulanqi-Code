﻿#ifndef BROWSERENGINEVIEW_H
#define BROWSERENGINEVIEW_H

#include <QWidget>
#include <QWebEngineView>
#include "MainWindow.h"


class BrowserEngineView : public QWebEngineView
{
    Q_OBJECT

public:
    explicit BrowserEngineView(QWidget *w = nullptr,QWebEngineView *parent = nullptr);
    ~BrowserEngineView();
    QWebEngineView *createWindow(QWebEnginePage::WebWindowType type);

private:
    MainWindow *webmain;
};

#endif // BROWSERENGINEVIEW_H
