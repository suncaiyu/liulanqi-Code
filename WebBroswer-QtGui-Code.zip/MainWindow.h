﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QAbstractNativeEventFilter>
#include <Windows.h>
#pragma comment(lib, "user32.lib")

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    QTabWidget *tabw;
protected:




public slots:
    void titleChange(const QString &str);
    void removeitem(int index);

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
