﻿#include "MainWindow.h"
#include "ui_MainWindow.h"
#include "BrowserEngineView.h"
#include <QStackedLayout>
#include <QHBoxLayout>
#include <QUrl>
#include <qdebug.h>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    BrowserEngineView *m_webView = new BrowserEngineView(this);
    tabw = ui->tabWidget;
    QHBoxLayout* layout = new QHBoxLayout();
    ui->tab->setLayout(layout);
    m_webView->load(QUrl("http://www.baidu.com/"));
    connect(m_webView, SIGNAL(titleChanged(const QString &)),this,SLOT(titleChange(const QString &)));
    connect(ui->tabWidget, SIGNAL(tabCloseRequested(int)), this, SLOT(removeitem(int)));
    qDebug() << m_webView->title();
    qDebug() << m_webView->url();
    layout->addWidget(m_webView);
    ui->tabWidget->removeTab(1);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::titleChange(const QString &str)
{
    ui->tabWidget->setTabText(ui->tabWidget->currentIndex(), str);
}

void MainWindow::removeitem(int index)
{
    ui->tabWidget->removeTab(index);
}