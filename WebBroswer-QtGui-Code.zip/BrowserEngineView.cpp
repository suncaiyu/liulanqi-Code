﻿#include "BrowserEngineView.h"
#include <QWebEngineView>

BrowserEngineView::BrowserEngineView(QWidget *p,QWebEngineView *parent)
{
    webmain = (MainWindow *)p;
}

BrowserEngineView::~BrowserEngineView()
{
}

QWebEngineView *BrowserEngineView::createWindow(QWebEnginePage::WebWindowType type)
{
    BrowserEngineView *webview = new BrowserEngineView(webmain);
    webmain->tabw->addTab(webview,webview->title());
    webmain->tabw->setCurrentIndex(webmain->tabw->count()-1);
    connect(webview,SIGNAL(titleChanged(const QString &)),webmain,SLOT(titleChange(const QString &)));
    return webview;
}
