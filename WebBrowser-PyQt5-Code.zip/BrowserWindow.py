from PyQt5.QtCore import QUrl, QSize, Qt
from PyQt5.QtGui import QIcon, QPixmap
from PyQt5.QtWebEngineWidgets import QWebEngineView
from PyQt5.QtWidgets import QToolBar,qApp, QAction, QApplication, QLineEdit, QProgressBar, QLabel, QMainWindow, QTabWidget, QStatusBar,QSystemTrayIcon, QMenu

import About
import ctypes
from ctypes.wintypes import UINT
from ctypes import WINFUNCTYPE, c_bool, c_int

from Resource import *


class BrowserEngineView(QWebEngineView):
    tabs = []

    def __init__(self, Main, parent=None):
        super(BrowserEngineView, self).__init__(parent)
        self.mainWindow = Main

    def createWindow(self, QWebEnginePage_WebWindowType):
        webview = BrowserEngineView(self.mainWindow)
        tab = BrowserTab(self.mainWindow)
        tab.browser = webview
        tab.setCentralWidget(tab.browser)
        self.tabs.append(tab)
        self.mainWindow.add_new_tab(tab)
        return webview


class BrowserTab(QMainWindow):
    def __init__(self, Main, parent=None):
        super(BrowserTab, self).__init__(parent)
        self.mainWindow = Main
        self.AboutDialog = About.AboutDialog()
        self.browser = BrowserEngineView(self.mainWindow)
        self.browser.load(QUrl(""))
        self.setCentralWidget(self.browser)
        self.navigation_bar = QToolBar('Navigation')
        self.navigation_bar.setIconSize(QSize(32, 32))
        self.navigation_bar.setMovable(False)
        self.addToolBar(self.navigation_bar)
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)

        self.back_button = QAction(QIcon(':/Assets/back.png'), '后退', self)
        self.next_button = QAction(QIcon(':/Assets/forward.png'), '前进', self)
        self.stop_button = QAction(QIcon(':/Assets/stop.png'), '停止', self)
        self.refresh_button = QAction(QIcon(':/Assets/refresh.png'), '刷新', self)
        self.home_button = QAction(QIcon(':/Assets/home.png'), '主页', self)
        self.enter_button = QAction(QIcon(':/Assets/enter.png'), '转到', self)
        self.add_button = QAction(QIcon(':/Assets/new.png'), '新建标签页', self)
        self.ssl_label1 = QLabel(self)
        self.ssl_label2 = QLabel(self)
        self.url_text_bar = QLineEdit(self)
        self.url_text_bar.setMinimumWidth(300)
        self.progress_bar = QProgressBar()
        self.progress_bar.setMaximumWidth(120)
        self.set_button = QAction(QIcon(':/Assets/setting.png'), '设置', self)
        self.navigation_bar.addAction(self.back_button)
        self.navigation_bar.addAction(self.next_button)
        self.navigation_bar.addAction(self.stop_button)
        self.navigation_bar.addAction(self.refresh_button)
        self.navigation_bar.addAction(self.home_button)
        self.navigation_bar.addAction(self.add_button)
        self.navigation_bar.addSeparator()
        self.navigation_bar.addWidget(self.ssl_label1)
        self.navigation_bar.addWidget(self.ssl_label2)
        self.navigation_bar.addWidget(self.url_text_bar)
        self.navigation_bar.addAction(self.enter_button)
        self.navigation_bar.addSeparator()
        # self.navigation_bar.addWidget(self.progress_bar)
        self.navigation_bar.addAction(self.set_button)
        self.status_icon = QLabel()
        self.status_icon.setScaledContents(True)
        self.status_icon.setMaximumHeight(24)
        self.status_icon.setMaximumWidth(24)
        self.status_icon.setPixmap(QPixmap(":/Assets/main.png"))
        self.status_label = QLabel()
        self.status_label.setText(" 基于 PyQt5 以及 QWebEngineView 的网页浏览器 - " + self.mainWindow.version)
        self.status_bar.addWidget(self.status_icon)
        self.status_bar.addWidget(self.status_label, 100)
        self.status_bar.addWidget(self.progress_bar)

    def navigate_to_url(self):
        s = QUrl(self.url_text_bar.text())
        if s.scheme() == '':
            s.setScheme('http')
        self.browser.load(s)

    def navigate_to_home(self):
        s = QUrl("http://www.hao123.com/")
        self.browser.load(s)

    def renew_urlbar(self, s):
        prec = s.scheme()
        if prec == 'http':
            self.ssl_label1.setPixmap(QPixmap(":/Assets/unsafe.png").scaledToHeight(24))
            self.ssl_label2.setText(" 不安全 ")
            self.ssl_label2.setStyleSheet("color:red;")
        elif prec == 'https':
            self.ssl_label1.setPixmap(QPixmap(":/Assets/safe.png").scaledToHeight(24))
            self.ssl_label2.setText(" 安全 ")
            self.ssl_label2.setStyleSheet("color:green;")
        self.url_text_bar.setText(s.toString())
        self.url_text_bar.setCursorPosition(0)

    def renew_progress_bar(self, p):
        self.progress_bar.setValue(p)

    def create_about_window(self):
        self.AboutDialog.show()


class BrowserWindow(QMainWindow):
    name = "PyQt5-WebBrowser"
    version = "2.0 Beta 3"
    date = "2018.12.03"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.setWindowTitle(self.name + " " + self.version)
        self.setWindowIcon(QIcon(':/Assets/main.png'))
        self.resize(1200, 900)
        self.tabs = QTabWidget()
        self.tabs.setTabsClosable(True)
        self.tabs.setMovable(True)
        self.tabs.setTabShape(0)
        self.setCentralWidget(self.tabs)
        self.tabs.tabCloseRequested.connect(self.close_current_tab)
        self.init_tab = BrowserTab(self)
        self.init_tab.browser.load(QUrl("http://www.hao123.com/"))
        self.add_new_tab(self.init_tab)
        self.setWindowOpacity(0.6)
        self.setWindowTitle("浏览器")
        self.setWindowIcon(QIcon(":/Assets/easyicon_net_64.ico"))



        self.mSysTrayIcon = QSystemTrayIcon()
        self.icon = QIcon("C:\\Users\\hp\\Desktop\\cailiao\\1.jpg")
        self.mSysTrayIcon.setIcon(self.icon)
        self.mSysTrayIcon.setToolTip("防锁屏工具")
        self.showapp = QAction("显示",self,triggered=self.showapp)
        self.closeapp= QAction("关闭",self,triggered=qApp.exit)
        self.mMenu = QMenu()
        self.mMenu.addAction(self.closeapp)
        self.mMenu.addAction(self.showapp)
        self.mSysTrayIcon.setContextMenu(self.mMenu)

    def showapp(self):
        self.show()
        self.mSysTrayIcon.hide()

    def add_blank_tab(self):
        blank_tab = BrowserTab(self)
        self.add_new_tab(blank_tab)

    def add_new_tab(self, tab):
        i = self.tabs.addTab(tab, "")
        self.tabs.setCurrentIndex(i)
        tab.back_button.triggered.connect(tab.browser.back)
        tab.next_button.triggered.connect(tab.browser.forward)
        tab.stop_button.triggered.connect(tab.browser.stop)
        tab.refresh_button.triggered.connect(tab.browser.reload)
        tab.home_button.triggered.connect(tab.navigate_to_home)
        tab.enter_button.triggered.connect(tab.navigate_to_url)
        tab.add_button.triggered.connect(self.add_blank_tab)
        tab.set_button.triggered.connect(tab.create_about_window)
        tab.url_text_bar.returnPressed.connect(tab.navigate_to_url)
        tab.browser.urlChanged.connect(tab.renew_urlbar)
        tab.browser.loadProgress.connect(tab.renew_progress_bar)
        tab.browser.titleChanged.connect(lambda title: (self.tabs.setTabText(i, title),
                                                        self.tabs.setTabToolTip(i, title)))
        tab.browser.iconChanged.connect(lambda icon: self.tabs.setTabIcon(i, icon))

    def close_current_tab(self, i):
        if self.tabs.count() > 1:
            self.tabs.removeTab(i)
        else:
            self.close()
    def keyPressEvent(self, e):
        if e.modifiers() == Qt.ControlModifier and e.key() == Qt.Key_Q:
            if self.isVisible():
                self.mSysTrayIcon.show()
                self.hide()
            elif self.isVisible() == False:
                self.mSysTrayIcon.hide()
                self.show()
        elif e.modifiers() == Qt.ControlModifier and e.key() == Qt.Key_Up:
            i = self.windowOpacity()
            i = i + 0.1
            self.setWindowOpacity(i)
        elif e.modifiers() == Qt.ControlModifier and e.key() == Qt.Key_Down:
            i = self.windowOpacity()
            i = i - 0.1
            self.setWindowOpacity(i)